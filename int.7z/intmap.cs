﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InteMap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            panel2.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            label2.Text = "Финиш";
            label3.Text = ":)";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            label2.Text = "МЦК Лужники";
            label3.Text = "Стенд для питья\nЭнергетические батончики";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            label2.Text = "Новодевичей монастырь";
            label3.Text = "Стенд для питья\nЭнергетические батончики\nТуалеты\nИнформация\nМедицинский пункт";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            label2.Text = "МИД";
            label3.Text = "Стенд для питья\nЭнергетические батончики\nТуалеты\nМедицинский пункт";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            label2.Text = "Парк Горького";
            nap.; 
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            label2.Text = "Здания РАН";
            label3.Text = "Стенд для питья\nЭнергетические батончики\nТуалеты";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            label2.Text = "Метро Воробьевы горы";
            label3.Text = "Стенд для питья\nЭнергетические батончики\nТуалеты\nТуалеты\nМедицинский пункт";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            label2.Text = "Стадион Лужники";
            label3.Text = "Стенд для питья\nЭнергетические батончики\nТуалеты\nТуалеты\nМедицинский пункт";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            label2.Text = "Старт";
            label3.Text = "Начало пути";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            label2.Text = "Старт";
            label3.Text = "Середина пути";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            label2.Text = "Старт";
            label3.Text = "Конец пути";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            label5.Text = "Напитки";
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            label5.Text = "Энергетические батончики";
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            label5.Text = "Информация";
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            label5.Text = "Туалет";
        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            label5.Text = "Медицинские пункты";
        }
    }
}
