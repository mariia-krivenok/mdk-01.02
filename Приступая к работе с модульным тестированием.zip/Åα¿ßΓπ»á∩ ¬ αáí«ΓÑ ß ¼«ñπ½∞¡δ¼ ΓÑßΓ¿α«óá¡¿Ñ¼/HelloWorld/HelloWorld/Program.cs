﻿namespace HelloWorld
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello World!");

        }

        public static void SayGoodbay()
        { Console.WriteLine("Goodbye World!");
        }
    }
}
